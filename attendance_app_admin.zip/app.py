import os
import sqlite3
from datetime import datetime, date
from io import BytesIO
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, send_file, session
)

# -------------------
# الإعدادات الأساسية
# -------------------
APP_NAME = "نظام حضور وانصراف"
DB_PATH = os.path.join(os.path.dirname(__file__), "attendance.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-in-production")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123")  # عدّلها في الإنتاج

# -------------------
# أدوات قاعدة البيانات
# -------------------
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            name TEXT
        );
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_code TEXT NOT NULL,
            check_in TEXT NOT NULL,
            check_out TEXT,
            FOREIGN KEY (employee_code) REFERENCES employees(code)
        );
    """)
    conn.commit()
    conn.close()

init_db()

# -------------------
# توابع مساعدة
# -------------------
def normalize_code(code: str) -> str:
    if not code:
        return ""
    return code.strip()

def get_employee(code):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM employees WHERE code = ?", (code,))
    row = cur.fetchone()
    conn.close()
    return row

def list_employees():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT code, name FROM employees ORDER BY code ASC")
    rows = cur.fetchall()
    conn.close()
    return rows

def ensure_employee(code, name=None):
    code = normalize_code(code)
    if not code:
        raise ValueError("كود الموظف مطلوب.")
    emp = get_employee(code)
    if emp:
        return emp
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO employees (code, name) VALUES (?, ?)", (code, name or code))
    conn.commit()
    conn.close()
    return get_employee(code)

def get_open_session(code):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM sessions 
        WHERE employee_code = ? AND check_out IS NULL
        ORDER BY id DESC LIMIT 1
    """, (code,))
    s = cur.fetchone()
    conn.close()
    return s

def check_in(code):
    code = normalize_code(code)
    if not code:
        raise ValueError("كود الموظف مطلوب.")
    ensure_employee(code)
    if get_open_session(code):
        raise ValueError("لا يمكن تسجيل حضور: هناك جلسة مفتوحة بالفعل لهذا الموظف.")
    now_iso = datetime.now().isoformat(timespec="seconds")
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO sessions (employee_code, check_in) VALUES (?, ?)", (code, now_iso))
    conn.commit()
    conn.close()
    return now_iso

def check_out(code):
    code = normalize_code(code)
    if not code:
        raise ValueError("كود الموظف مطلوب.")
    open_s = get_open_session(code)
    if not open_s:
        raise ValueError("لا توجد جلسة حضور مفتوحة لتسجيل الانصراف لهذا الموظف.")
    now_iso = datetime.now().isoformat(timespec="seconds")
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE sessions SET check_out = ? WHERE id = ?", (now_iso, open_s["id"]))
    conn.commit()
    conn.close()
    return now_iso

def parse_month(yyyymm: str):
    try:
        year, month = map(int, yyyymm.split("-"))
        _ = date(year, month, 1)
        return year, month
    except Exception:
        raise ValueError("صيغة الشهر غير صحيحة. استخدم YYYY-MM مثل 2025-08")

def month_bounds(year: int, month: int):
    from calendar import monthrange
    start = datetime(year, month, 1)
    last_day = monthrange(year, month)[1]
    end = datetime(year, month, last_day, 23, 59, 59)
    return start, end

def fetch_month_sessions(code: str, yyyymm: str):
    code = normalize_code(code)
    year, month = parse_month(yyyymm)
    start, end = month_bounds(year, month)

    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM sessions 
        WHERE employee_code = ?
          AND (
                (datetime(check_in) BETWEEN ? AND ?)
                OR
                (check_out IS NOT NULL AND datetime(check_out) BETWEEN ? AND ?)
              )
        ORDER BY datetime(check_in) ASC
    """, (code, start.isoformat(sep=" "), end.isoformat(sep=" "),
          start.isoformat(sep=" "), end.isoformat(sep=" ")))
    rows = cur.fetchall()
    conn.close()
    return rows

def seconds_between(a_iso, b_iso):
    a = datetime.fromisoformat(a_iso)
    b = datetime.fromisoformat(b_iso)
    return int((b - a).total_seconds())

def human_hours_minutes(total_seconds: int):
    h = total_seconds // 3600
    m = (total_seconds % 3600) // 60
    return f"{h:02d}:{m:02d}"

def aggregate_report(rows):
    from collections import defaultdict
    per_day = defaultdict(list)
    total_seconds = 0

    for r in rows:
        check_in_ts = r["check_in"]
        check_out_ts = r["check_out"]
        d_key = datetime.fromisoformat(check_in_ts).date().isoformat()
        duration_sec = 0
        if check_out_ts:
            duration_sec = seconds_between(check_in_ts, check_out_ts)
            if duration_sec > 0:
                total_seconds += duration_sec
        per_day[d_key].append({
            "check_in": check_in_ts,
            "check_out": check_out_ts or "—",
            "duration": max(0, duration_sec)
        })

    daily_rows = []
    for day in sorted(per_day.keys()):
        for i, sess in enumerate(per_day[day], start=1):
            daily_rows.append({
                "day": day,
                "idx": i,
                "check_in": sess["check_in"],
                "check_out": sess["check_out"],
                "duration_hm": human_hours_minutes(sess["duration"])
            })

    return daily_rows, human_hours_minutes(total_seconds)

# ------------- حماية الإدارة -------------
def require_admin(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if not session.get("admin_auth"):
            flash("يجب تسجيل الدخول للوصول إلى صفحة الإدارة.", "error")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapper

# -------------------
# الواجهات (Routes)
# -------------------
@app.route("/", methods=["GET"])
def index():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT employee_code, check_in, check_out
        FROM sessions
        ORDER BY id DESC
        LIMIT 10
    """)
    last_ops = cur.fetchall()
    conn.close()
    return render_template("index.html", app_name=APP_NAME, last_ops=last_ops)

@app.route("/check-in", methods=["POST"])
def route_check_in():
    code = normalize_code(request.form.get("code", ""))
    try:
        ts = check_in(code)
        flash(f"تم تسجيل الحضور للموظف {code} في {ts}", "ok")
    except Exception as e:
        flash(str(e), "error")
    return redirect(url_for("index"))

@app.route("/check-out", methods=["POST"])
def route_check_out():
    code = normalize_code(request.form.get("code", ""))
    try:
        ts = check_out(code)
        flash(f"تم تسجيل الانصراف للموظف {code} في {ts}", "ok")
    except Exception as e:
        flash(str(e), "error")
    return redirect(url_for("index"))

# ---------- الدخول/الخروج للإدارة ----------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        pwd = request.form.get("password", "")
        if pwd == ADMIN_PASSWORD:
            session["admin_auth"] = True
            flash("تم تسجيل الدخول بنجاح.", "ok")
            next_url = request.args.get("next") or url_for("admin")
            return redirect(next_url)
        else:
            flash("كلمة المرور غير صحيحة.", "error")
    return render_template("login.html", app_name=APP_NAME)

@app.route("/logout")
def logout():
    session.pop("admin_auth", None)
    flash("تم تسجيل الخروج.", "ok")
    return redirect(url_for("index"))

# ---------- صفحة الإدارة ----------
@app.route("/admin", methods=["GET", "POST"])
@require_admin
def admin():
    # إضافة موظف
    if request.method == "POST" and request.form.get("action") == "add_employee":
        code = normalize_code(request.form.get("emp_code", ""))
        name = request.form.get("emp_name", "") or code
        try:
            ensure_employee(code, name)
            flash(f"تمت إضافة الموظف: {name} ({code})", "ok")
        except sqlite3.IntegrityError:
            flash("الكود موجود بالفعل.", "error")
        except Exception as e:
            flash(str(e), "error")
        return redirect(url_for("admin"))

    # إعداد بيانات التقرير إذا طلِب
    report_data = None
    selected_code = request.args.get("code")
    selected_month = request.args.get("month", datetime.now().strftime("%Y-%m"))
    if selected_code:
        rows = fetch_month_sessions(selected_code, selected_month)
        daily_rows, total_hm = aggregate_report(rows)
        emp = get_employee(selected_code)
        emp_name = emp["name"] if emp else selected_code
        report_data = {
            "code": selected_code,
            "emp_name": emp_name,
            "month": selected_month,
            "daily_rows": daily_rows,
            "total_hm": total_hm
        }

    return render_template("admin.html",
                           app_name=APP_NAME,
                           employees=list_employees(),
                           report_data=report_data,
                           selected_month=selected_month)

# -------- تصدير CSV/Excel/PDF (محمية) --------
@app.route("/export/csv")
@require_admin
def export_csv():
    import csv, io
    code = normalize_code(request.args.get("code", ""))
    yyyymm = request.args.get("month", datetime.now().strftime("%Y-%m"))
    rows = fetch_month_sessions(code, yyyymm)
    daily_rows, total_hm = aggregate_report(rows)

    sio = io.StringIO()
    writer = csv.writer(sio)
    writer.writerow(["كود الموظف", code])
    writer.writerow(["الشهر", yyyymm])
    writer.writerow([])
    writer.writerow(["اليوم", "الجلسة", "حضور", "انصراف", "المدة (س:د)"])
    for r in daily_rows:
        writer.writerow([r["day"], r["idx"], r["check_in"], r["check_out"], r["duration_hm"]])
    writer.writerow([])
    writer.writerow(["الإجمالي", "", "", "", total_hm])

    data = sio.getvalue().encode("utf-8-sig")
    return send_file(BytesIO(data), mimetype="text/csv; charset=utf-8",
                     as_attachment=True, download_name=f"report_{code}_{yyyymm}.csv")

@app.route("/export/xlsx")
@require_admin
def export_xlsx():
    import xlsxwriter
    code = normalize_code(request.args.get("code", ""))
    yyyymm = request.args.get("month", datetime.now().strftime("%Y-%m"))
    rows = fetch_month_sessions(code, yyyymm)
    daily_rows, total_hm = aggregate_report(rows)

    output = BytesIO()
    wb = xlsxwriter.Workbook(output, {'in_memory': True})
    ws = wb.add_worksheet("التقرير")
    bold = wb.add_format({'bold': True})
    ws.write("A1", "كود الموظف", bold); ws.write("B1", code)
    ws.write("A2", "الشهر", bold); ws.write("B2", yyyymm)
    ws.write("A4", "اليوم", bold); ws.write("B4", "الجلسة", bold); ws.write("C4", "حضور", bold)
    ws.write("D4", "انصراف", bold); ws.write("E4", "المدة (س:د)", bold)
    r = 4
    for row in daily_rows:
        ws.write(r, 0, row["day"]); ws.write(r, 1, row["idx"]); ws.write(r, 2, row["check_in"])
        ws.write(r, 3, row["check_out"]); ws.write(r, 4, row["duration_hm"]); r += 1
    ws.write(r+1, 0, "الإجمالي", bold); ws.write(r+1, 4, total_hm, bold)
    wb.close(); output.seek(0)
    return send_file(output, as_attachment=True,
                     download_name=f"report_{code}_{yyyymm}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@app.route("/export/pdf")
@require_admin
def export_pdf():
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import cm
    code = normalize_code(request.args.get("code", ""))
    yyyymm = request.args.get("month", datetime.now().strftime("%Y-%m"))
    rows = fetch_month_sessions(code, yyyymm)
    daily_rows, total_hm = aggregate_report(rows)

    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    x_margin = 2 * cm; y = height - 2 * cm
    c.setFont("Helvetica-Bold", 14); c.drawString(x_margin, y, f"تقرير الحضور الشهري - {yyyymm}")
    y -= 1.0 * cm; c.setFont("Helvetica", 12); c.drawString(x_margin, y, f"كود الموظف: {code}")
    y -= 0.8 * cm
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, "اليوم"); c.drawString(x_margin + 4.0*cm, y, "جلسة")
    c.drawString(x_margin + 6.0*cm, y, "حضور"); c.drawString(x_margin + 12.0*cm, y, "انصراف")
    c.drawString(x_margin + 16.0*cm, y, "المدة")
    y -= 0.5 * cm; c.setFont("Helvetica", 10)
    for row in daily_rows:
        if y < 2.5 * cm:
            c.showPage(); y = height - 2 * cm; c.setFont("Helvetica-Bold", 11)
            c.drawString(x_margin, y, "اليوم"); c.drawString(x_margin + 4.0*cm, y, "جلسة")
            c.drawString(x_margin + 6.0*cm, y, "حضور"); c.drawString(x_margin + 12.0*cm, y, "انصراف")
            c.drawString(x_margin + 16.0*cm, y, "المدة"); y -= 0.5 * cm; c.setFont("Helvetica", 10)
        c.drawString(x_margin, y, row["day"]); c.drawString(x_margin + 4.0*cm, y, str(row["idx"]))
        c.drawString(x_margin + 6.0*cm, y, row["check_in"]); c.drawString(x_margin + 12.0*cm, y, row["check_out"])
        c.drawString(x_margin + 16.0*cm, y, row["duration_hm"]); y -= 0.5 * cm
    y -= 0.5 * cm; c.setFont("Helvetica-Bold", 12); c.drawString(x_margin, y, f"الإجمالي: {total_hm}")
    c.showPage(); c.save(); buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"report_{code}_{yyyymm}.pdf",
                     mimetype="application/pdf")

# -------------------
# تشغيل التطبيق
# -------------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
